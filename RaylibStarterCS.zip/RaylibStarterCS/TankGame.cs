﻿using System;
using System.Collections.Generic;
using System.Text;
using static Raylib_cs.Raylib;

namespace RaylibStarterCS
{
    class TankGame : Game
    {
        public override void Init()
        {
            base.Init();
        }

    }
}
